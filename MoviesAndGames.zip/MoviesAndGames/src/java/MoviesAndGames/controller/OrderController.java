/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MoviesAndGames.controller;

import MoviesAndGames.entity.Customer;
import MoviesAndGames.entity.Order;
import MoviesAndGames.entity.Product;
import MoviesAndGames.session.CustomerEJB;
import MoviesAndGames.session.OrderEJB;
import MoviesAndGames.session.ProductEJB;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;

/**
 *
 * This controller class will delegates the request from the order and performs
 * the order related operations
 */
@Named("orderBean")
@ManagedBean
@RequestScoped
public class OrderController {

    @EJB
    private OrderEJB orderEJB; // Beans for order
    @EJB
    private ProductEJB productEJB;// Beans for product
    @EJB
    private CustomerEJB customerEJB;// Beans for customer
    private Order order = new Order(); // order object for storing order
    private Customer customer = new Customer();// customer object for storing customer
    private Product product = new Product();// product object for storing prodcut 
    private List<Customer> customerList = new ArrayList(); //list for storing customer
    private List<Product> productList = new ArrayList();// product arraylist
    private List<Order> orderList = new ArrayList<Order>();//order arraylist

    //loading customer,product and order
    @PostConstruct
    public void init() {
        customerList = customerEJB.findCustomer();
        productList = productEJB.findProducts();
        orderList = orderEJB.findOrders();
    }
// return product
    public Product getProduct() {
        return product;
    }
// set product
    public void setProduct(Product product) {
        this.product = product;
    }

    // Public Methods     for creating oder       
    public String createOrder() {
        // Get customer
        customer = customerEJB.findOne(customer);
        //GEt product
        product = productEJB.findOne(product);
        // Product
        System.out.println("product:" + product);
        List<Product> productList = new ArrayList<Product>();
        productList.add(product);
        order.setCustomer(customer);
        order.setProductList(productList);
        order.setCreationDate(new Date());
        order.setPrice(product.getPrice());
        // create order
        order = orderEJB.createOrder(order);

        // subtracting the stock number
        product.setStock_Number(product.getStock_Number() - order.getQuantity());
        productEJB.updateProduct(product);
        //reload 
        init();
        FacesContext ctx = FacesContext.getCurrentInstance();
        ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucessfully created the Order for :", "" + customer.getName()));
        return "listOrder.xhtml";
    }

    //Getters  for order      
    public Order getOrder() {
        return order;
    }
//setter for order
    public void setOrder(Order order) {
        this.order = order;
    }
//get orderlist
    public List<Order> getOrderList() {
        return orderList;
    }
//set orderlist
    public void setOrderList(List<Order> orderList) {
        this.orderList = orderList;
    }
//insert order
    public void insert(Order order) {
        orderEJB.createOrder(order);
    }
//update order
    public void update(Order order) {
        orderEJB.updateOrder(order);
    }
//delete order
    public void delete(Order order) {
        // get product and update stock no
        int noOFStock = order.getQuantity();
        product = order.getProductList().get(0);
        product.setStock_Number(noOFStock + product.getStock_Number());

        productEJB.updateProduct(product);
        // delete order
        orderEJB.deleteOrder(order);
        findAll();
    }
// return all order
    public List<Order> findAll() {
        orderList = orderEJB.findOrders();
        return orderList;
    }
// find one order by id
    public String findOne() {
        this.orderList = null;
        this.orderList = new ArrayList<>();
        this.order = orderEJB.findOne(this.order);
        this.orderList.add(order);
        return "order.xhtml";
    }
// return customer
    public Customer getCustomer() {
        return customer;
    }
//set customer
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
// get customer list
    public List<Customer> getCustomerList() {
        return customerList;
    }
// set customer list
    public void setCustomerList(List<Customer> customerList) {
        this.customerList = customerList;
    }
//get productlist
    public List<Product> getProductList() {
        return productList;
    }
//set product list
    public void setProductList(List<Product> productList) {
        this.productList = productList;
    }
// find order by id
    public String findOrderById() {
        this.orderList = null;
        this.orderList = orderEJB.findOrdersByID(this.order);
        if (this.orderList == null) {
            System.out.println("not found");
            return "notfound.xhtml";
        } else {
            System.out.println("Order found");
        }
        return "order.xhtml";
    }

}
