/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MoviesAndGames.controller;

import MoviesAndGames.entity.Game;
import MoviesAndGames.entity.Movie;
import MoviesAndGames.entity.Product;
import MoviesAndGames.session.ProductEJB;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * This controller class will delegates the request from the product and performs
 * the product related operations
 */
@ManagedBean
@RequestScoped
public class ProductController {

    @EJB
    private ProductEJB productEJB;//product ejb
    private Product product = new Product();// new product
    private List<Product> productList = new ArrayList<Product>(); //storing the product list
    private List<Movie> movieList = new ArrayList<Movie>();// storing the movieist

// insert product
    public String CreateProduct() {
        product = productEJB.createProduct(product);
        findAll();
        return "listProduct.xhtml";
    }

 // get product         
    public Product getProduct() {
        return product;
    }
//set product
    public void setProduct(Product product) {
        this.product = product;
    }
// get the productlist
    public List<Product> getProductList() {
        return productList;
    }
// set the productlist
    public void setProductList(List<Product> productList) {
        this.productList = productList;
    }
// insert the product
    public void insert(Product product) {
        productEJB.createProduct(product);
    }
// update the product
    public void update(Product product) {
        productEJB.updateProduct(product);
    }
// delete the prodcut
    public void delete(Product product) {
        productEJB.deleteProduct(product);
    }
// find all product
    public List<Product> findAll() {
        productList = productEJB.findProducts();
        return productList;
    }
// get one prodcut
    public Product findOne(Product product) {
        return productEJB.findOne(product);
    }
// display product details
    public String productDetails(Product product) {
        System.out.println("product" + product);
        if (product instanceof Movie) {
            return new MoviesController().goToMovieDetail((Movie)product);
         
        } else {
            return new GamesController().goToGameDetail((Game) product);
        }
    }

}
