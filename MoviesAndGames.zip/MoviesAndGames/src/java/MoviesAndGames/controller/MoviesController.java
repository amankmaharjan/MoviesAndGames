/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MoviesAndGames.controller;

import MoviesAndGames.entity.Movie;
import MoviesAndGames.session.*;
import static com.sun.faces.facelets.tag.composite.ImplementationHandler.Name;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;

/**
 *
 * This controller class will delegates the request from the movie and performs
 * the movie related operations
 */
@Named("movieBean")
@ManagedBean()
@RequestScoped
public class MoviesController {

    @EJB
    private MoviesEJB movieEJB; //movie ejb
    private Movie movie = new Movie();// movie object for storing movie
    private List<Movie> movieList = new ArrayList<Movie>(); // list for storing movielist

    @PostConstruct
    public void init() {
        movieList = movieEJB.findMovies();
    }

    //Getters & Setters         
    public Movie getMovie() {
        return movie;
    }
//set movie

    public void setMovie(Movie movie) {
        this.movie = movie;
    }
//returnt the movie list

    public List<Movie> getMoviesList() {
        return movieList;
    }
//set the movie list

    public void setMoviesList(List<Movie> movieList) {
        this.movieList = movieList;
    }
//insert the movie

    public String insert() {
        this.movie = movieEJB.createMovies(movie);
        findAllMovies();
        FacesContext ctx = FacesContext.getCurrentInstance();
        ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucessfully created the movie:", "" + this.movie.getTitle()));
        return "stockMovie.xhtml";
    }
//update the movie

    public void update(Movie movie) {
        movieEJB.updateMovies(movie);
    }
//delet the movie

    public void delete(Movie movie) {
        movieEJB.deleteMovies(movie);
    }
//find one movie

    public void findOne() {
        movie = movieEJB.findOne(movie);
        System.out.println(movie);

    }

//   find movies by title
    public String findByTitle() {
        this.movieList = null;
        this.movieList = movieEJB.findMovieByTitle(this.movie);
        if (this.movieList == null) {
            System.out.println("not found");
            return "notfound.xhtml";
        } else {
            System.out.println("movie found");
        }
        return "movie.xhtml";
    }
// find all movies

    public String findAllMovies() {
        this.movieList = movieEJB.findMovies();
        return "movies/stockMovie.xhtml";
    }
// Display movie detal

    public String goToMovieDetail(Movie movie) {
        this.movieList = null;
        System.out.println("inside movie detail:");
        this.movieList = new ArrayList<Movie>();
        this.movieList.add(movie);
        return "movie.xhtml";
    }
}
