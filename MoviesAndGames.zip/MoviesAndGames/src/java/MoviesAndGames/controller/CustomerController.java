/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import MoviesAndGames.entity.Customer;
import MoviesAndGames.session.CustomerEJB;
import MoviesAndGames.session.OrderEJB;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

/**
 *
 * This controller class will delegates the request from the customer and
 * performs the customer related operations
 */
@ManagedBean
@RequestScoped
public class CustomerController {

    @EJB
    private CustomerEJB customerEJB; // Cusomter EJB beans
    @EJB
    private OrderEJB orderEJB; // Order EJB beans
    private Customer customer = new Customer(); // Customer object to store customer infomraiton
    private List<Customer> customerList = new ArrayList<Customer>(); //customerlist object to hold list of customer

    @PostConstruct
    public void init() {
        this.findAllCustomer(); // loads all customer
    }

    //Customer Getters       
    public Customer getCustomer() {
        return customer;
    }

    // Customer Setter
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    // CusotmerList getter
    public List<Customer> getCustomerList() {
        return customerList;
    }
    // Customer List setter

    public void setcustomerList(List<Customer> customerList) {
        this.customerList = customerList;
    }
    // insert Customer
    public String insert() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        customer = customerEJB.createCustomer(customer);
        ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucessfully created the Customer:", "" + customer.getName()));
        findAllCustomer();
        return "listCustomers.xhtml";

    }
    // udpate customer
    public void update(Customer customer) {
        customerEJB.updateCustomer(customer);
    }
    // delete the cusomer
    public void delete(Customer customer) {
        customerEJB.deleteCustomer(customer);
    }

    // find all customer
    public String findAllCustomer() {
        this.customerList = customerEJB.findCustomer();
        for (Customer c : customerList) {
            c.setOrderList(orderEJB.findByCustomerID(c));
        }
        System.out.println(customerList);
        return "customer/listCustomers.xhtml";
    }
    // find one customer
    public void findOne() {
        customer = customerEJB.findOne(customer);

    }
    // find customer by name
    public String findByName() {
        this.customerList = customerEJB.findByCustomeName(this.customer);
        if (this.customerList == null) {
            System.out.println("not found");
            return "notfound.xhtml";
        }
        return "customer.xhtml";
    }
    // display customer details
    public String displayCustomerDetails(Customer customer) {
        customer.setOrderList(orderEJB.findByCustomerID(customer));
        this.customerList = new ArrayList<>();
        this.customerList.add(customer);
        return "customerDetail.xhtml";
    }

}
