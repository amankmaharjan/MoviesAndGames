/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MoviesAndGames.controller;

import MoviesAndGames.entity.Game;
import MoviesAndGames.session.GamesEJB;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;

/**
 *
 * This controller class will delegates the request from the games and performs
 * the games related operations
 */
@Named("gameBean")
@ManagedBean
@RequestScoped
public class GamesController {

    @EJB
    private GamesEJB gameEJB; //  Games EJB beans
    private Game game = new Game(); // Game object for holding game
    private List<Game> gameList = new ArrayList<Game>(); // Arraylist for holding the gamelist

    @PostConstruct
    public void init() {
        gameList = gameEJB.findGames(); // find games  at the start
    }

    //Getters for game      
    public Game getGame() {
        return game;
    }
    //Setters for game      

    public void setGame(Game game) {
        this.game = game;
    }
    //Getters for game list     

    public List<Game> getGamesList() {
        return gameList;
    }
    //Setters for game List     

    public void setGamesList(List<Game> gameList) {
        this.gameList = gameList;
    }
// insert the game

    public String insert() {
        this.game = gameEJB.createGames(game);
        findAllGames();
        FacesContext ctx = FacesContext.getCurrentInstance();
        ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucessfully created the game:", "" + this.game.getTitle()));
        return "listGames.xhtml";
    }

    // Update the game
    public void update(Game game) {
        gameEJB.updateGames(game);
    }
    // delete the game

    public void delete(Game game) {
        gameEJB.deleteGames(game);
    }

    // find one game by id
    public void findOne() {
        game = gameEJB.findOne(game);
        System.out.println(game);

    }

    // find game by title
    public String findByTitle() {
        this.gameList = gameEJB.findOneGameTitle(this.game);
        if (this.gameList == null) {
            System.out.println("not found");
            return "notfound.xhtml";
        }
        return "game.xhtml";
    }
// find all games

    public String findAllGames() {
        this.gameList = gameEJB.findGames();
        return "games/listGames.xhtml";
    }
// diplay game detail

    public String goToGameDetail(Game game) {
        this.gameList = null;
        System.out.println("inside movie detail:");
        this.gameList = new ArrayList<Game>();
        this.gameList.add(game);
        return "game.xhtml";
    }
}
