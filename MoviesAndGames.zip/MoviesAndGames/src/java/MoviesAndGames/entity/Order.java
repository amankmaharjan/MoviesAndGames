/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MoviesAndGames.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * Order entity class
 */
@Entity
@Table(name = "OrderDetail")
public class Order implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;// primary key
    @ManyToMany
    private List<Product> productList;// product list field
    @ManyToOne
    private Customer customer;// customer field
    @Temporal(TemporalType.DATE)
    private Date creationDate;// creation date
    private String status;// status field
    private int quantity;// quantity field
    private float price;// price field

    //Cosntructor
    public Order() {
    }

    // Getter for quantity
    public int getQuantity() {
        return quantity;
    }
    // Setter for quantity

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
//Getter for productList

    public List<Product> getProductList() {
        return productList;
    }
//Setter for productList

    public void setProductList(List<Product> productList) {
        this.productList = productList;
    }
//Getter for id

    public int getId() {
        return id;
    }

//Setter for id
    public void setId(int id) {
        this.id = id;
    }
//Getter for creationDate

    public Date getCreationDate() {
        return creationDate;
    }
//Setter for creationDate

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }
//Getter for status

    public String getStatus() {
        return status;
    }
//Setter for status

    public void setStatus(String status) {
        this.status = status;
    }

    //Getter for Customer
    public Customer getCustomer() {
        return customer;
    }
//Setter for Customer

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
// Getter for price

    public float getPrice() {
        return price;
    }
//Setter for price

    public void setPrice(float price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Order{" + "id=" + id + ", productList=" + productList + ", creationDate=" + creationDate + ", status=" + status + '}';
    }

}
