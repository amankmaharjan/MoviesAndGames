/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MoviesAndGames.entity;

import java.io.Serializable;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 *
 *Entity class for storing the game
 */

@Entity
@DiscriminatorValue("G")
public class Game extends Product implements Serializable {

    private String HD_Video_Output; // hd video output field
    private int HD_Space; // hd space field
    private int number_of_Players;// no  of player field
// constuctor
    public Game() {
    }
//Getter for HD_Video_Output

    public String getHD_Video_Output() {
        return HD_Video_Output;
    }
//setter for HD_Video_Output

    public void setHD_Video_Output(String HD_Video_Output) {
        this.HD_Video_Output = HD_Video_Output;
    }
// Getter for HD_Space
    public int getHD_Space() {
        return HD_Space;
    }
// setter for HD_Space

    public void setHD_Space(int HD_Space) {
        this.HD_Space = HD_Space;
    }
// Getter for number_of_Players

    public int getNumber_of_Players() {
        return number_of_Players;
    }
// Setter for number_of_Players
    public void setNumber_of_Players(int number_of_Players) {
        this.number_of_Players = number_of_Players;
    }

    @Override
    public String toString() {
        return "Games{" + "HD_Video_Output=" + HD_Video_Output + ", HD_Space=" + HD_Space + ", number_of_Players=" + number_of_Players + '}';
    }
    
}
