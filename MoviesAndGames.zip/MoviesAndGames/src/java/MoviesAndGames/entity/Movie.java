/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MoviesAndGames.entity;

import java.io.Serializable;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

/**
 *
 *Entity class for movie
 */
@Entity
@DiscriminatorValue("M")
public class Movie extends Product implements Serializable {

    private int duration; // duration field
    private String special_Features;// special features field
//constructor
    public Movie() {
    }

  // constructor
    public Movie(Long id, String Title, String Description, String Company, String Platform, String Classification, float Price, int Stock_Number) {
        super(id, Title, Description, Company, Platform, Classification, Price, Stock_Number);
    }
//constructor
    public Movie(int duration, String special_Features) {
        this.duration = duration;
        this.special_Features = special_Features;
    }
// Getter for duration
    public int getDuration() {
        return duration;
    }
// Setter for duration

    public void setDuration(int duration) {
        this.duration = duration;
    }
// Getter for special_Features

    public String getSpecial_Features() {
        return special_Features;
    }
// Setter for special_Features

    public void setSpecial_Features(String special_Features) {
        this.special_Features = special_Features;
    }

    @Override
    public String toString() {
        return "Movies{" + "duration=" + duration + ", special_Features=" + special_Features + '}';
    }

  
 

}
