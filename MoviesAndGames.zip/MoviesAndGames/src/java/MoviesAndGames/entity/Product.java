/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MoviesAndGames.entity;

import java.io.Serializable;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

/**
 *
 * Entity class for product
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "type")
public class Product implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id; //primary key
    private String Title; //title field
    private String Description;// description field
    private String Company;// company field
    private String Platform;// platform field
    private String Classification;// classification field
    private float Price;// price
    private int Stock_Number; //stock nubmer field

    // constructor
    public Product() {
    }
// constructor

    public Product(Long id, String Title, String Description, String Company, String Platform, String Classification, float Price, int Stock_Number) {
        this.id = id;
        this.Title = Title;
        this.Description = Description;
        this.Company = Company;
        this.Platform = Platform;
        this.Classification = Classification;
        this.Price = Price;
        this.Stock_Number = Stock_Number;
    }
    //Getter for id

    public Long getId() {
        return id;
    }
//Setter for id

    public void setId(Long id) {
        this.id = id;
    }
//Gtter for title

    public String getTitle() {
        return Title;
    }
//Setter for title
    public void setTitle(String Title) {
        this.Title = Title;
    }


//Getter for description

    public String getDescription() {
        return Description;
    }
//Setter for description

    public void setDescription(String Description) {
        this.Description = Description;
    }
//Getter for Company

    public String getCompany() {
        return Company;
    }
//Setter for Company

    public void setCompany(String Company) {
        this.Company = Company;
    }
//Getter for platform

    public String getPlatform() {
        return Platform;
    }
//Setter for platform

    public void setPlatform(String Platform) {
        this.Platform = Platform;
    }
//Getter for Classification

    public String getClassification() {
        return Classification;
    }
//Setter for Classification

    public void setClassification(String Classification) {
        this.Classification = Classification;
    }
// getter for price
    public float getPrice() {
        return Price;
    }
// Setter for price

    public void setPrice(float Price) {
        this.Price = Price;
    }
// getter for stock number

    public int getStock_Number() {
        return Stock_Number;
    }
// setter for stock number

    public void setStock_Number(int Stock_Number) {
        this.Stock_Number = Stock_Number;
    }

    //To string implementation
    @Override
    public String toString() {
        return "Products{" + "id=" + id + ", Title=" + Title + ", Description=" + Description + ", Company=" + Company + ", Platform=" + Platform + ", Classification=" + Classification + ", Price=" + Price + ", Stock_Number=" + Stock_Number + '}';
    }

}
