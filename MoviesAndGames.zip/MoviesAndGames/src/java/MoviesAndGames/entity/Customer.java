/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MoviesAndGames.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * Entity class for customer
 */
@Entity
public class Customer implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id; //  primary key
    private String name; // name field
    private String address; // address field
    private int phoneNumber; // phone number field
    private String email;// email field
    @OneToMany(mappedBy ="customer")
    private List<Order>orderList; //ordr list

    public Customer() {
    }
//Getter for name
    public String getName() {
        return name;
    }
//setter for name

    public void setName(String name) {
        this.name = name;
    }
//Getter for Address

    public String getAddress() {
        return address;
    }
//Setter for address

    public void setAddress(String address) {
        this.address = address;
    }
//Getter for phone number

    public int getPhoneNumber() {
        return phoneNumber;
    }
//setter for phone number

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
//Getter for email

    public String getEmail() {
        return email;
    }
//Setter for email

    public void setEmail(String email) {
        this.email = email;
    }
//Getter for Id

    public Long getId() {
        return id;
    }
//setter for id

    public void setId(Long id) {
        this.id = id;
    }

  //Getter for orderlist

    public List<Order> getOrderList() {
        return orderList;
    }
//setter for orderlist

    public void setOrderList(List<Order> orderList) {
        this.orderList = orderList;
    }

    @Override
    public String toString() {
        return "Customer{" + "id=" + id + ", name=" + name + ", address=" + address + ", phoneNumber=" + phoneNumber + ", email=" + email + ", orderList=" + orderList + '}';
    }

}
