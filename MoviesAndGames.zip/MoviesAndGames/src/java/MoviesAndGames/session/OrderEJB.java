package MoviesAndGames.session;

import MoviesAndGames.entity.Customer;
import MoviesAndGames.entity.Order;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * This EJB class will delegates the request from the orderController and
 * performs the order related database operations
 */
@Stateless
public class OrderEJB {

    // Entity manager             
    @PersistenceContext(unitName = "MoviesAndGamesPU")
    private EntityManager em;

    // find all orders       
    public List<Order> findOrders() {
        Query query = em.createQuery("SELECT m FROM Order m");
        return query.getResultList();
    }
// create order
    public Order createOrder(Order order) {
        em.persist(order);
        return order;
    }
// delete the order
    public void deleteOrder(Order order) {
        em.remove(findOne(order));
    }
// update the order
    public void updateOrder(Order editedorder) {

        Order order = findOne(editedorder);
        if (order != null) {
            order.setCreationDate(editedorder.getCreationDate());
            
        }
        em.persist(order);
    }
// get one order
    public Order findOne(Order order) {
        return em.find(Order.class, order.getId());
    }
// find order by id
    public List<Order> findOrdersByID(Order order) {
        TypedQuery<Order> query = em.createQuery("SELECT o from Order o where o.ID=?1", Order.class);
        query.setParameter(1, order.getId());
        List< Order> orderList = query.getResultList();
        return orderList;
    }
// find orders by customer id
    public List<Order> findByCustomerID(Customer customer) {
        TypedQuery<Order> query = em.createQuery("SELECT o from Order o where o.customer.id=?1", Order.class);
        query.setParameter(1, customer.getId());
        List< Order> orderList = query.getResultList();
        return orderList;
    }
}
