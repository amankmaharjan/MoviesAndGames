package MoviesAndGames.session;

import MoviesAndGames.entity.Customer;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * This EJB class will delegates the request from the customerController and
 * performs the customer related database operations
 */
@Stateless
public class CustomerEJB {

    // Entitiy manager             
    @PersistenceContext(unitName = "MoviesAndGamesPU")
    private EntityManager em;

    // Get all the customers         
    public List<Customer> findCustomer() {
        Query query = em.createQuery("SELECT m FROM Customer m");
        return query.getResultList();
    }
// create the customer
    public Customer createCustomer(Customer customer) {
        em.persist(customer);
        return customer;
    }
// delete the customer
    public void deleteCustomer(Customer customer) {
        em.remove(customer.getId());
    }
// update the customer
    public void updateCustomer(Customer editedcustomer) {

        Customer customer = findOne(editedcustomer);
        customer.setAddress(editedcustomer.getAddress());
        customer.setEmail(editedcustomer.getEmail());
        customer.setName(editedcustomer.getName());
        em.persist(customer);
    }
// find one customer by id
    public Customer findOne(Customer customer) {
        return em.find(Customer.class, customer.getId());
    }
// find customers by name
    public List<Customer> findByCustomeName(Customer customer) {
        System.out.println("customer name:" + customer.getName());
        TypedQuery<Customer> query = em.createQuery("SELECT m from Customer m where m.name=?1", Customer.class);
        query.setParameter(1, customer.getName());
        List<Customer> customerList = query.getResultList();
        return customerList;
    }
}
