package MoviesAndGames.session;

import MoviesAndGames.entity.Game;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * This EJB class will delegates the request from the gamesController and
 * performs the games related database operations
 */
@Stateless
public class GamesEJB {

    // Entitiy manager             
    @PersistenceContext(unitName = "MoviesAndGamesPU")
    private EntityManager em;

    // find gameslist          
    public List<Game> findGames() {
        Query query = em.createQuery("SELECT m FROM Game m");
        return query.getResultList();
    }
// create games
    public Game createGames(Game game) {
        em.persist(game);
        return game;
    }
// delete game
    public void deleteGames(Game game) {
        em.remove(game.getId());
    }
// update game
    public void updateGames(Game editedgame) {

        Game game = findOne(editedgame);
        if (game != null) {
            game.setPrice(editedgame.getPrice());
            game.setHD_Space(editedgame.getHD_Space());
            game.setTitle(editedgame.getTitle());
            game.setPlatform(editedgame.getPlatform());
            game.setNumber_of_Players(editedgame.getNumber_of_Players());
            game.setCompany(editedgame.getCompany());
            game.setClassification(editedgame.getClassification());
            
        }
        em.persist(game);
    }
// find one game by id
    public Game findOne(Game game) {
        return em.find(Game.class, game.getId());
    }
// find  list games by title
    public List<Game> findOneGameTitle(Game game) {
        TypedQuery<Game> query = em.createQuery("SELECT m from Game m where m.Title=?1", Game.class);
        query.setParameter(1, game.getTitle());
        List<Game> gameList = query.getResultList();
        return gameList;
    }
}
