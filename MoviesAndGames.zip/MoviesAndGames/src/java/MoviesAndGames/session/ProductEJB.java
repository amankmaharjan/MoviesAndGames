package MoviesAndGames.session;

import MoviesAndGames.entity.Product;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * This EJB class will delegates the request from the productController and
 * performs the order related database operations
 */
@Stateless
public class ProductEJB {

    // Entity manager             
    @PersistenceContext(unitName = "MoviesAndGamesPU")
    private EntityManager em;

    // Find all products           
    public List<Product> findProducts() {
        Query query = em.createQuery("SELECT m FROM Product m");
        return query.getResultList();
    }
// create the product
    public Product createProduct(Product product) {
        em.persist(product);
        return product;
    }
// delete the product
    public void deleteProduct(Product product) {
        em.remove(product.getId());
    }
// update the product
    public void updateProduct(Product editedproduct) {

        Product product = findOne(editedproduct);
        if (product != null) {
            product.setStock_Number(editedproduct.getStock_Number());
            product.setClassification(editedproduct.getClassification());
            product.setCompany(editedproduct.getCompany());
            product.setDescription(editedproduct.getDescription());
            product.setPlatform(editedproduct.getPlatform());
            product.setTitle(editedproduct.getTitle());
        }
        em.persist(product);
    }
// find one procut by id
    public Product findOne(Product product) {
        return em.find(Product.class, product.getId());
    }
}
