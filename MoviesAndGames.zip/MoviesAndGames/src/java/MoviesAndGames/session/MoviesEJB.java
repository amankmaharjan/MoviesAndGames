package MoviesAndGames.session;

import MoviesAndGames.entity.Movie;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * This EJB class will delegates the request from the gamesController and
 * performs the games related database operations
 */
@Stateless
public class MoviesEJB {

    // Entity manager             
    @PersistenceContext(unitName = "MoviesAndGamesPU")
    private EntityManager em;

    //  Methods that  finds all movies          
    public List<Movie> findMovies() {
        Query query = em.createQuery("SELECT m FROM Movie m");
        return query.getResultList();
    }
// create the movie
    public Movie createMovies(Movie movie) {
        em.persist(movie);
        return movie;
    }
// delete the movie
    public void deleteMovies(Movie movie) {
        em.remove(movie.getId());
    }
// update movie
    public void updateMovies(Movie editedmovie) {

        Movie movie = findOne(editedmovie);
        if (movie != null) {
            movie.setDuration(editedmovie.getDuration());
            movie.setClassification(editedmovie.getClassification());
            movie.setCompany(editedmovie.getCompany());
            movie.setDescription(editedmovie.getDescription());
            movie.setPlatform(editedmovie.getPlatform());
            movie.setPrice(editedmovie.getPrice());
            movie.setSpecial_Features(editedmovie.getSpecial_Features());
            movie.setStock_Number(editedmovie.getStock_Number());
        }
        em.persist(movie);
    }
// find one moive byid
    public Movie findOne(Movie movie) {
        return em.find(Movie.class, movie.getId());
    }
// find movies by title
    public List<Movie> findMovieByTitle(Movie movie) {
        TypedQuery<Movie> query = em.createQuery("SELECT m from Movie m where m.Title=?1", Movie.class);
        query.setParameter(1, movie.getTitle());
        List< Movie> movieList = query.getResultList();
        return movieList;
    }
}
